
package Liga;

import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.TableModel;
import net.proteanit.sql.DbUtils;



public class Zmluva extends javax.swing.JFrame {

    
    Connection con = null;
    Statement st = null;
    ResultSet rs =null;
    
    
    public Zmluva() {
        initComponents();
        connectDatabase();
    
        fillcombobox();
    }

    public void connectDatabase(){
        String host ="jdbc:postgresql://localhost/postgres2";
        String uName ="postgres";
        String uPass ="rolandkubik";

       
        try {
            con = DriverManager.getConnection(host, uName, uPass);
        } catch (SQLException ex) {
            Logger.getLogger(MainWindow.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(rootPane,"Nie je možné pripojiť sa k databáze ! " , "Chyba !", 1 );
        }
        
    } 
    public void fillcombobox(){
    
    
        try {
            st = con.createStatement();
            rs = st.executeQuery("SELECT priezvisko FROM hrac ");
            
            while (rs.next())
            {
                String trener = rs.getString(1);
                
                hraccombo.addItem(trener);
                
                
            }
            rs = st.executeQuery("SELECT nazov_klubu FROM klub");
            
            while (rs.next())
            {
                String trener = rs.getString(1);
                
                klubcombo.addItem(trener);
                
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(Zmluva.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
 
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        platnostod = new javax.swing.JTextField();
        platnostdo = new javax.swing.JTextField();
        pridattrener = new javax.swing.JButton();
        hraccombo = new javax.swing.JComboBox();
        klubcombo = new javax.swing.JComboBox();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Tréner");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Pridať novú zmluvu"));

        jLabel1.setText("Platnosť od :");

        jLabel2.setText("Platnosť do :");

        pridattrener.setText("Pridať");
        pridattrener.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                pridattrenerAncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        pridattrener.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pridattrenerActionPerformed(evt);
            }
        });

        klubcombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                klubcomboActionPerformed(evt);
            }
        });

        jLabel13.setText("Hráč :");

        jLabel14.setText("Klub :");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))
                        .addGap(12, 12, 12))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(18, 18, 18)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(platnostod)
                    .addComponent(platnostdo)
                    .addComponent(pridattrener, javax.swing.GroupLayout.DEFAULT_SIZE, 223, Short.MAX_VALUE)
                    .addComponent(hraccombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(klubcombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(hraccombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(klubcombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(platnostod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(platnostdo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addComponent(pridattrener))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void pridattrenerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pridattrenerActionPerformed

        try {
            st = con.createStatement();
            st.executeUpdate("INSERT INTO zmluva (platnost_od,platnost_do) VALUES ('"+platnostod.getText()+"','"+platnostdo.getText()+"')");
            rs = st.executeQuery("SELECT klub_id FROM klub WHERE nazov_klubu='"+klubcombo.getSelectedItem().toString()+"'");
            rs.next();
            int klubid  = rs.getInt(1);
            st.executeUpdate("UPDATE zmluva SET klub_id ='"+klubid+"' WHERE klub_id='50'");
            rs = st.executeQuery("SELECT hrac_id FROM hrac WHERE priezvisko='"+hraccombo.getSelectedItem().toString()+"'");
            rs.next();
            int hracid  = rs.getInt(1);
            st.executeUpdate("UPDATE zmluva SET hrac_id ='"+hracid+"' WHERE hrac_id='50'");
            JOptionPane.showMessageDialog(rootPane, "Úspešne pridaná !");
            platnostod.setText(null);
            platnostdo.setText(null);

            platnostod.requestFocus();
     
            fillcombobox();
        } catch (SQLException ex) {
            Logger.getLogger(Zmluva.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(rootPane, "Chyba ! !");
            platnostod.setText(null);
            platnostdo.setText(null);
         
            platnostod.requestFocus();
        }
    }//GEN-LAST:event_pridattrenerActionPerformed

    private void pridattrenerAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_pridattrenerAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_pridattrenerAncestorAdded

    private void klubcomboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_klubcomboActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_klubcomboActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Zmluva.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Zmluva.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Zmluva.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Zmluva.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Zmluva().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox hraccombo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JComboBox klubcombo;
    private javax.swing.JTextField platnostdo;
    private javax.swing.JTextField platnostod;
    private javax.swing.JButton pridattrener;
    // End of variables declaration//GEN-END:variables
}
